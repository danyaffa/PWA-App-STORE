# SafeLaunch API Documentation

Base URL: `https://api.safelaunch.app/api` (production)  
Local:    `http://localhost:3001/api`

All protected endpoints require `Authorization: Bearer <JWT>` header.

---

## Authentication

### POST /api/auth/register
Create a new publisher account.

**Body:**
```json
{
  "name": "Dev Studio",
  "email": "hello@devstudio.com",
  "password": "securepassword"
}
```
**Response:** `201`
```json
{ "token": "eyJ...", "publisher": { "id": "uuid", "name": "Dev Studio", "plan": "lite" } }
```

---

### POST /api/auth/login
Login and receive JWT.

**Body:**
```json
{ "email": "hello@devstudio.com", "password": "securepassword" }
```
**Response:** `200`
```json
{ "token": "eyJ...", "publisher": { "id": "uuid", "name": "Dev Studio", "plan": "lite" } }
```

---

## Apps

### GET /api/apps
List published apps. Supports filtering and search.

**Query params:**
| Param | Type | Description |
|---|---|---|
| `category` | string | Filter by category |
| `q` | string | Full-text search |
| `sort` | string | `installs`, `risk_score`, `newest` |
| `page` | int | Page number (default: 1) |
| `limit` | int | Results per page (default: 20, max: 50) |

**Response:** `200`
```json
{
  "apps": [...],
  "total": 1247,
  "page": 1
}
```

---

### GET /api/apps/:id
Get a single app with its current version and latest scan result.

**Response:** `200`
```json
{
  "id": "uuid",
  "name": "FocusFlow",
  "category": "Productivity",
  "status": "live",
  "trust_badge": "verified",
  "install_count": 12048,
  "current_version": { "version_string": "2.3.1", "risk_score": 5, "decision": "ALLOW" }
}
```

---

## Submit & Scan

### POST /api/submit  🔒
Upload a new app or version for scanning.

**Body (multipart/form-data):**
| Field | Type | Required |
|---|---|---|
| `file` | ZIP file | one of file/github_url/pwa_url |
| `github_url` | string | — |
| `pwa_url` | string | — |
| `name` | string | ✓ (new apps) |
| `category` | string | ✓ (new apps) |
| `description` | string | ✓ (new apps) |
| `privacy_url` | string | ✓ |
| `contact_email` | string | ✓ |
| `app_id` | UUID | for updates to existing apps |
| `build_cmd` | string | override build command |

**Response:** `202`
```json
{
  "version_id": "uuid",
  "app_id": "uuid",
  "status": "building",
  "message": "Build started. Poll /api/scan/:version_id for progress."
}
```

---

### GET /api/scan/:versionId  🔒
Poll scan status and results.

**Response:** `200`
```json
{
  "version_id": "uuid",
  "build_status": "success",
  "scan_status": "complete",
  "risk_score": 12,
  "decision": "ALLOW",
  "summary": { "critical": 0, "high": 0, "medium": 1, "low": 0, "pass": 14 },
  "findings": [...],
  "explanation": {
    "headline": "✅ ALLOW — Ready to Publish",
    "summary": "...",
    "action": "Click Publish Now to make your app live.",
    "fixes": []
  }
}
```

---

### POST /api/publish/:versionId  🔒
Publish an ALLOW or reviewer-approved version to the store.

**Response:** `200`
```json
{ "app_id": "uuid", "status": "live", "store_url": "https://safelaunch.app/apps/focusflow" }
```

---

## Reports

### GET /api/reports/:versionId
Get the full scan report (public for live apps).

**Response:** `200`
```json
{
  "version_id": "uuid",
  "app": { "name": "FocusFlow", "version": "2.3.1" },
  "risk_score": 5,
  "decision": "ALLOW",
  "scanned_at": "2026-01-14T02:42:42Z",
  "summary": { "critical": 0, "high": 0, "medium": 0, "low": 0, "pass": 16 },
  "findings": [...],
  "sbom": [...],
  "build_log": "..."
}
```

---

## Dashboard (publisher)

### GET /api/dashboard  🔒
Get publisher's apps, stats, and recent activity.

**Response:** `200`
```json
{
  "stats": {
    "total_installs": 24891,
    "active_apps": 4,
    "avg_risk_score": 9,
    "report_count": 0
  },
  "apps": [...],
  "recent_activity": [...],
  "alerts": [...]
}
```

---

## Trust Ops (admin only)

### GET /api/admin/queue  🔒🔒
Get submissions pending human review.

### POST /api/admin/approve/:versionId  🔒🔒
Approve a REVIEW submission.

### POST /api/admin/block/:versionId  🔒🔒
Block a submission and optionally strike the publisher.

**Body:**
```json
{ "reason": "Crypto-miner detected", "strike": true }
```

---

## Error Codes

| Code | Meaning |
|---|---|
| `400` | Validation error |
| `401` | Missing or invalid token |
| `403` | Insufficient permissions |
| `404` | Resource not found |
| `409` | Conflict (duplicate app name/slug) |
| `422` | Build failed |
| `429` | Rate limit exceeded |
| `500` | Internal server error |
