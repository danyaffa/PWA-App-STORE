# SafeLaunch Deployment Guide

## Option A — GitHub Pages (Frontend only, free)

1. Push repo to GitHub
2. Go to **Settings → Pages → Source → GitHub Actions**
3. The `deploy.yml` workflow runs automatically on every push to `main`
4. Your store will be live at `https://YOUR_USERNAME.github.io/PWA-App-Store/`

**That's it for the frontend.**

---

## Option B — Full Stack (Frontend + API + DB)

### Prerequisites
- Node.js 20+
- PostgreSQL 15+
- Docker (for build sandboxes)

### 1. Clone and install
```bash
git clone https://github.com/YOUR_USERNAME/PWA-App-Store.git
cd PWA-App-Store
```

### 2. Set up the database
```bash
createdb safelaunch
psql -U postgres -d safelaunch -f backend/db-schema.sql
psql -U postgres -d safelaunch -f backend/seed.sql
```

### 3. Configure environment
```bash
cp backend/.env.example backend/.env
```

Edit `backend/.env`:
```
DATABASE_URL=postgresql://postgres:password@localhost:5432/safelaunch
JWT_SECRET=your-super-secret-key-change-this
BUILD_WORKSPACE=/tmp/safelaunch-builds
PORT=3001
NODE_ENV=production
```

### 4. Install backend dependencies
```bash
cd backend && npm install
```

### 5. Start the API server
```bash
node server.js
# or with PM2: pm2 start server.js --name safelaunch-api
```

### 6. Serve the frontend
```bash
# With any static server:
cd ..
npx serve . --listen 3000
```

---

## Recommended Hosting Stack

| Layer | Recommended | Free tier |
|---|---|---|
| Frontend | GitHub Pages | ✅ Free |
| API | Railway or Render | ✅ Free tier |
| Database | Supabase or Railway | ✅ Free tier |
| Build sandboxes | Fly.io or self-hosted | Paid |
| CDN / artifacts | Cloudflare R2 | ✅ Free tier |

### Railway (recommended for API)
```bash
npm install -g @railway/cli
railway login
railway init
railway up
```
Set env vars in Railway dashboard.

---

## Update Nav Links After Hosting

Once you have a real URL, update the nav links in all HTML files from relative paths to your domain:

```bash
# Find and replace in all HTML files
find . -name "*.html" -exec sed -i 's|href="../|href="/|g' {} \;
```

Or keep them relative — they work fine for GitHub Pages subdirectory hosting.

---

## Custom Domain

1. Add a `CNAME` file to repo root:
   ```
   safelaunch.app
   ```
2. Configure your DNS: `CNAME store → YOUR_USERNAME.github.io`
3. Enable HTTPS in GitHub Pages settings
