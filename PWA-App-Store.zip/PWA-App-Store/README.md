# SafeLaunch — PWA App Store

> The trusted PWA store. Upload → Auto-build → AI safety scan → Publish → Install.

![SafeLaunch](https://img.shields.io/badge/SafeLaunch-PWA%20Store-00e5a0?style=for-the-badge)
![License](https://img.shields.io/badge/license-MIT-blue?style=for-the-badge)
![Status](https://img.shields.io/badge/status-MVP-orange?style=for-the-badge)

---

## What Is This?

SafeLaunch is an independent PWA app store with a mandatory AI-powered safety pipeline built in. Developers publish apps without needing Apple/Google accounts, certificates, or keystores. Every app is scanned before publish and monitored post-publish.

---

## Repo Structure

```
PWA-App-Store/
├── index.html              # Home / hero page
├── store.html              # Browse apps
├── publish.html            # Upload & submit
├── safety.html             # Safety pipeline explainer
├── pricing.html            # Plans & pricing
├── pages/
│   ├── app-detail.html     # Individual app listing page
│   ├── dashboard.html      # Publisher dashboard
│   ├── signin.html         # Sign in / register
│   ├── trust-ops.html      # Internal review queue (admin)
│   ├── scan-report.html    # Full scan report for a version
│   └── 404.html            # Not found page
├── api/
│   ├── README.md           # API documentation
│   ├── apps.js             # GET /api/apps — list/search apps
│   ├── submit.js           # POST /api/submit — upload & trigger build
│   ├── scan.js             # POST /api/scan — run safety pipeline
│   ├── publish.js          # POST /api/publish — set app live
│   ├── auth.js             # POST /api/auth/login|register
│   └── reports.js          # GET /api/reports/:versionId
├── backend/
│   ├── scanner.js          # Core 6-layer safety engine
│   ├── risk-score.js       # Risk scoring model
│   ├── build-sandbox.js    # Docker build orchestrator
│   ├── db-schema.sql       # PostgreSQL schema
│   └── seed.sql            # Demo data seed
├── manifest/
│   ├── manifest.json       # PWA manifest for the store itself
│   └── sw.js               # Service worker
├── docs/
│   ├── ARCHITECTURE.md     # System architecture deep-dive
│   ├── SAFETY.md           # Safety algorithm documentation
│   └── DEPLOY.md           # Deployment guide
└── .github/
    └── workflows/
        ├── deploy.yml      # Auto-deploy to GitHub Pages
        └── scan-pr.yml     # Run safety checks on PRs
```

---

## Quick Start

### 1. Clone the repo
```bash
git clone https://github.com/YOUR_USERNAME/PWA-App-Store.git
cd PWA-App-Store
```

### 2. Open locally
```bash
# No build step needed for the frontend
open index.html
# or serve with any static server:
npx serve .
```

### 3. Run the backend (Node.js)
```bash
cd backend
npm install
cp .env.example .env   # fill in DB_URL, OPENAI_KEY etc.
node server.js
```

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | HTML, CSS, Vanilla JS (no framework) |
| Backend API | Node.js + Express |
| Database | PostgreSQL |
| Build Sandbox | Docker |
| Safety Scanning | Custom engine + OWASP ZAP + npm audit |
| Auth | JWT + bcrypt |
| Hosting | GitHub Pages (frontend) + Railway/Render (API) |
| CI/CD | GitHub Actions |

---

## Pages

| File | Description |
|---|---|
| `index.html` | Hero, features, stats |
| `store.html` | Browse & search all apps |
| `publish.html` | Upload + build + scan flow |
| `safety.html` | Pipeline explainer + live risk demo |
| `pricing.html` | Plans, FAQ, billing toggle |
| `pages/app-detail.html` | Individual app page with trust report |
| `pages/dashboard.html` | Publisher dashboard — apps, scans, stats |
| `pages/signin.html` | Sign in / create account |
| `pages/trust-ops.html` | Admin review queue |
| `pages/scan-report.html` | Full per-version scan report |
| `pages/404.html` | Custom not found page |

---

## API Endpoints

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/apps` | List apps (filterable) |
| GET | `/api/apps/:id` | Single app detail |
| POST | `/api/submit` | Upload ZIP / connect GitHub |
| POST | `/api/scan/:versionId` | Trigger safety scan |
| GET | `/api/reports/:versionId` | Fetch scan report |
| POST | `/api/publish/:versionId` | Set version live |
| POST | `/api/auth/register` | Create publisher account |
| POST | `/api/auth/login` | Login, returns JWT |
| GET | `/api/dashboard` | Publisher's own apps + stats |

---

## Risk Scoring

| Severity | Points | Example |
|---|---|---|
| Critical | +60 | Malware, credential theft, phishing kit |
| High | +25 | XSS sink, unsafe eval, suspicious redirect |
| Medium | +10 | Weak CSP, outdated dep, missing policy |
| Low | +3 | Missing headers, minor config issues |
| Reputation bonus | -10 | Clean publisher, 8+ months, 0 strikes |

**Decision thresholds:** 0–29 = ALLOW ✅ · 30–59 = REVIEW ⚠️ · 60–100 = BLOCK 🚫

---

## License

MIT — see [LICENSE](LICENSE)
