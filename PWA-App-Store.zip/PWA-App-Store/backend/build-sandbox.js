/**
 * SafeLaunch — Build Sandbox Orchestrator
 * Pulls source, runs a sandboxed Docker build, returns artifact path.
 *
 * Requires: Docker installed on host, DOCKER_HOST env var if remote.
 */

'use strict';

const { execSync, spawnSync } = require('child_process');
const fs   = require('fs');
const path = require('path');
const os   = require('os');

const BUILD_IMAGE  = 'node:20-alpine';
const BUILD_TIMEOUT = 300_000; // 5 min
const WORKSPACE    = process.env.BUILD_WORKSPACE || path.join(os.tmpdir(), 'safelaunch-builds');

/**
 * Run a sandboxed build for a submitted version.
 *
 * @param {object} opts
 * @param {string} opts.versionId   UUID of the version record
 * @param {string} opts.sourceType  'zip' | 'github' | 'url'
 * @param {string} opts.sourceRef   ZIP path, GitHub URL, or hosted URL
 * @param {string} [opts.buildCmd]  Override build command (default: auto-detect)
 * @returns {{ success: boolean, artifactDir: string, buildLog: string, durationMs: number }}
 */
async function runBuild({ versionId, sourceType, sourceRef, buildCmd }) {
  const jobDir = path.join(WORKSPACE, versionId);
  const srcDir  = path.join(jobDir, 'source');
  const distDir = path.join(jobDir, 'dist');
  fs.mkdirSync(srcDir, { recursive: true });
  fs.mkdirSync(distDir, { recursive: true });

  const logLines = [];
  const log = msg => { console.log(msg); logLines.push(msg); };

  log(`[build] Job: ${versionId}`);
  log(`[build] Source type: ${sourceType}`);

  const t0 = Date.now();

  try {
    // ── 1. Fetch source ──────────────────────────────────────────────────────
    if (sourceType === 'zip') {
      log('[build] Extracting ZIP...');
      execSync(`unzip -q "${sourceRef}" -d "${srcDir}"`, { timeout: 30_000 });
    } else if (sourceType === 'github') {
      log(`[build] Cloning ${sourceRef}...`);
      execSync(`git clone --depth=1 "${sourceRef}" "${srcDir}"`, { timeout: 60_000 });
    } else if (sourceType === 'url') {
      log('[build] PWA URL mode — no build needed, using hosted artifact');
      return { success: true, artifactDir: null, buildLog: logLines.join('\n'), durationMs: Date.now() - t0 };
    }

    // ── 2. Detect framework / build command ──────────────────────────────────
    const cmd = buildCmd || detectBuildCommand(srcDir);
    log(`[build] Build command: ${cmd}`);

    // ── 3. Docker sandboxed build ────────────────────────────────────────────
    const dockerCmd = [
      'docker run --rm',
      '--network=none',                    // NO egress by default
      `--memory=512m`,
      `--cpus=1`,
      `--volume "${srcDir}":/app`,
      `--volume "${distDir}":/dist`,
      `--workdir /app`,
      BUILD_IMAGE,
      `/bin/sh -c "npm ci --prefer-offline && ${cmd} && cp -r ./dist/. /dist/ 2>/dev/null || cp -r ./build/. /dist/ 2>/dev/null || true"`,
    ].join(' ');

    log('[build] Starting Docker sandbox (network=none)...');
    const result = spawnSync('sh', ['-c', dockerCmd], {
      timeout: BUILD_TIMEOUT,
      encoding: 'utf8',
    });

    if (result.stdout) logLines.push(...result.stdout.split('\n'));
    if (result.stderr) logLines.push(...result.stderr.split('\n'));

    if (result.status !== 0) {
      log('[build] ✗ Build failed');
      return { success: false, artifactDir: null, buildLog: logLines.join('\n'), durationMs: Date.now() - t0 };
    }

    log(`[build] ✓ Build completed in ${((Date.now() - t0) / 1000).toFixed(1)}s`);
    return { success: true, artifactDir: distDir, buildLog: logLines.join('\n'), durationMs: Date.now() - t0 };

  } catch (err) {
    log(`[build] ✗ Error: ${err.message}`);
    return { success: false, artifactDir: null, buildLog: logLines.join('\n'), durationMs: Date.now() - t0 };
  }
}

/**
 * Auto-detect the build command from package.json scripts.
 */
function detectBuildCommand(srcDir) {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(srcDir, 'package.json'), 'utf8'));
    const scripts = pkg.scripts || {};
    if (scripts.build)       return 'npm run build';
    if (scripts['build:pwa']) return 'npm run build:pwa';
    if (scripts.export)      return 'npm run export';
  } catch (_) {}
  // Fallback
  return 'npm run build';
}

/**
 * Clean up a job workspace after scanning is complete.
 */
function cleanupJob(versionId) {
  const jobDir = path.join(WORKSPACE, versionId);
  try { execSync(`rm -rf "${jobDir}"`); } catch (_) {}
}

module.exports = { runBuild, cleanupJob, WORKSPACE };
