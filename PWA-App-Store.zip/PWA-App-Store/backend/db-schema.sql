-- SafeLaunch PostgreSQL Schema
-- Run: psql -U postgres -d safelaunch -f db-schema.sql

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ─────────────────────────────────────────────────────────────────────────────
-- PUBLISHERS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE publishers (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name             TEXT NOT NULL,
  email            TEXT NOT NULL UNIQUE,
  password_hash    TEXT NOT NULL,
  plan             TEXT NOT NULL DEFAULT 'lite'   CHECK (plan IN ('lite','pro','business')),
  verified         BOOLEAN NOT NULL DEFAULT FALSE,
  strikes          INTEGER NOT NULL DEFAULT 0,
  account_age_days INTEGER GENERATED ALWAYS AS
                     (EXTRACT(DAY FROM NOW() - created_at)::INTEGER) STORED,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────────────────────
-- APPS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE apps (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  publisher_id     UUID NOT NULL REFERENCES publishers(id) ON DELETE CASCADE,
  name             TEXT NOT NULL,
  slug             TEXT NOT NULL UNIQUE,
  description      TEXT NOT NULL,
  category         TEXT NOT NULL CHECK (category IN (
                     'Productivity','Finance','Health','Entertainment',
                     'Developer Tools','Education','Kids','Other'
                   )),
  status           TEXT NOT NULL DEFAULT 'draft'
                     CHECK (status IN ('draft','scanning','review','live','blocked','unlisted')),
  privacy_url      TEXT,
  contact_email    TEXT,
  icon_url         TEXT,
  trust_badge      TEXT DEFAULT 'none'
                     CHECK (trust_badge IN ('none','verified','review','blocked')),
  install_count    INTEGER NOT NULL DEFAULT 0,
  report_count     INTEGER NOT NULL DEFAULT 0,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_apps_publisher ON apps(publisher_id);
CREATE INDEX idx_apps_status ON apps(status);
CREATE INDEX idx_apps_category ON apps(category);

-- ─────────────────────────────────────────────────────────────────────────────
-- APP VERSIONS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE versions (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  app_id           UUID NOT NULL REFERENCES apps(id) ON DELETE CASCADE,
  version_string   TEXT NOT NULL,
  source_type      TEXT NOT NULL CHECK (source_type IN ('zip','github','url')),
  source_ref       TEXT NOT NULL,    -- zip path, github repo URL, or hosted URL
  source_commit    TEXT,             -- git commit SHA if github
  build_hash       TEXT,             -- SHA256 of built artifact
  artifact_url     TEXT,             -- CDN URL of built bundle
  build_status     TEXT NOT NULL DEFAULT 'pending'
                     CHECK (build_status IN ('pending','building','success','failed')),
  build_duration_s INTEGER,
  build_log_url    TEXT,
  is_current       BOOLEAN NOT NULL DEFAULT FALSE,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_versions_app ON versions(app_id);
CREATE INDEX idx_versions_current ON versions(app_id, is_current);

-- ─────────────────────────────────────────────────────────────────────────────
-- SCAN RESULTS
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE scan_results (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  version_id       UUID NOT NULL REFERENCES versions(id) ON DELETE CASCADE,
  scan_type        TEXT NOT NULL DEFAULT 'full'
                     CHECK (scan_type IN ('full','quick','continuous')),
  risk_score       INTEGER NOT NULL CHECK (risk_score BETWEEN 0 AND 100),
  decision         TEXT NOT NULL CHECK (decision IN ('ALLOW','REVIEW','BLOCK')),
  -- Engine breakdown
  critical_count   INTEGER NOT NULL DEFAULT 0,
  high_count       INTEGER NOT NULL DEFAULT 0,
  medium_count     INTEGER NOT NULL DEFAULT 0,
  low_count        INTEGER NOT NULL DEFAULT 0,
  pass_count       INTEGER NOT NULL DEFAULT 0,
  -- Raw findings JSON
  findings         JSONB NOT NULL DEFAULT '[]',
  sbom             JSONB,
  -- Reviewer
  reviewer_id      UUID REFERENCES publishers(id),
  reviewer_notes   TEXT,
  reviewed_at      TIMESTAMPTZ,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_scans_version ON scan_results(version_id);
CREATE INDEX idx_scans_decision ON scan_results(decision);

-- findings JSONB structure per item:
-- {
--   "engine": "sast|sca|secrets|dast|policy|reputation",
--   "severity": "critical|high|medium|low|pass|info",
--   "title": "Short title",
--   "detail": "Full description",
--   "fix": "How to fix",
--   "cve": "CVE-2024-XXXXX",  -- optional
--   "points": 25
-- }

-- ─────────────────────────────────────────────────────────────────────────────
-- POLICY RULES
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE policy_rules (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  rule_code        TEXT NOT NULL UNIQUE,
  engine           TEXT NOT NULL,
  severity         TEXT NOT NULL CHECK (severity IN ('critical','high','medium','low')),
  description      TEXT NOT NULL,
  detection_pattern TEXT,
  auto_action      TEXT NOT NULL DEFAULT 'score'
                     CHECK (auto_action IN ('score','block','flag')),
  points           INTEGER NOT NULL DEFAULT 0,
  applies_to       TEXT[] DEFAULT '{}',  -- empty = all categories
  enabled          BOOLEAN NOT NULL DEFAULT TRUE,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────────────────────
-- USER REPORTS (abuse reports from store users)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE user_reports (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  app_id           UUID NOT NULL REFERENCES apps(id) ON DELETE CASCADE,
  reporter_email   TEXT,
  reason           TEXT NOT NULL CHECK (reason IN (
                     'malware','phishing','spam','adult_content',
                     'copyright','broken','other'
                   )),
  detail           TEXT,
  evidence_url     TEXT,
  status           TEXT NOT NULL DEFAULT 'open'
                     CHECK (status IN ('open','reviewing','resolved','dismissed')),
  resolved_by      UUID REFERENCES publishers(id),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_reports_app ON user_reports(app_id);
CREATE INDEX idx_reports_status ON user_reports(status);

-- ─────────────────────────────────────────────────────────────────────────────
-- AUDIT LOG (immutable)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE audit_log (
  id               BIGSERIAL PRIMARY KEY,
  actor_id         UUID,              -- NULL = system
  actor_type       TEXT NOT NULL CHECK (actor_type IN ('system','reviewer','publisher')),
  action           TEXT NOT NULL,     -- e.g. 'app.blocked', 'scan.completed', 'version.published'
  target_type      TEXT,
  target_id        UUID,
  detail           JSONB,
  ip_address       INET,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_target ON audit_log(target_type, target_id);
CREATE INDEX idx_audit_actor ON audit_log(actor_id);
CREATE INDEX idx_audit_time ON audit_log(created_at DESC);

-- ─────────────────────────────────────────────────────────────────────────────
-- CONTINUOUS MONITORING SCHEDULE
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE monitoring_schedule (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  app_id           UUID NOT NULL REFERENCES apps(id) ON DELETE CASCADE,
  frequency        TEXT NOT NULL DEFAULT 'weekly'
                     CHECK (frequency IN ('daily','weekly','monthly')),
  last_run_at      TIMESTAMPTZ,
  next_run_at      TIMESTAMPTZ NOT NULL DEFAULT NOW() + INTERVAL '7 days',
  enabled          BOOLEAN NOT NULL DEFAULT TRUE,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ─────────────────────────────────────────────────────────────────────────────
-- REVIEWS (store user app reviews)
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE app_reviews (
  id               UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  app_id           UUID NOT NULL REFERENCES apps(id) ON DELETE CASCADE,
  reviewer_handle  TEXT NOT NULL,
  stars            INTEGER NOT NULL CHECK (stars BETWEEN 1 AND 5),
  body             TEXT NOT NULL,
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_reviews_app ON app_reviews(app_id);

-- ─────────────────────────────────────────────────────────────────────────────
-- updated_at trigger
-- ─────────────────────────────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_publishers_updated BEFORE UPDATE ON publishers
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_apps_updated BEFORE UPDATE ON apps
  FOR EACH ROW EXECUTE FUNCTION set_updated_at();
