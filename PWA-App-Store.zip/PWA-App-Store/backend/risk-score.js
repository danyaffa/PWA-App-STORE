/**
 * SafeLaunch — Risk Scoring Model
 * Converts findings array into a 0–100 score + ALLOW/REVIEW/BLOCK decision.
 */

'use strict';

const POINTS = {
  critical:   60,
  high:       25,
  medium:     10,
  low:         3,
  pass:        0,
  info:        0,
};

const REPUTATION_BONUS = -10; // applied for trusted publishers

// Decision thresholds
const THRESHOLDS = {
  ALLOW:  29,   // 0–29
  REVIEW: 59,   // 30–59
  BLOCK:  100,  // 60–100
};

/**
 * @param {Array}  findings  - Array of finding objects from scanner.js
 * @param {Object} metadata  - Publisher metadata (age, strikes, clean versions)
 * @returns {{ score: number, decision: string, breakdown: object }}
 */
function calculate(findings, metadata = {}) {
  let raw = 0;
  const breakdown = { critical: 0, high: 0, medium: 0, low: 0, bonus: 0 };

  for (const f of findings) {
    const pts = POINTS[f.severity] || 0;
    raw += pts;
    if (f.severity in breakdown) breakdown[f.severity] += pts;
  }

  // Reputation bonus: trusted publisher with 3+ clean versions, 0 strikes
  const { publisher_strikes = 0, prior_clean_versions = 0 } = metadata;
  if (publisher_strikes === 0 && prior_clean_versions >= 3) {
    raw += REPUTATION_BONUS;
    breakdown.bonus = REPUTATION_BONUS;
  }

  // Clamp to 0–100
  const score = Math.max(0, Math.min(100, raw));

  let decision;
  if (score <= THRESHOLDS.ALLOW)  decision = 'ALLOW';
  else if (score <= THRESHOLDS.REVIEW) decision = 'REVIEW';
  else decision = 'BLOCK';

  return { score, decision, breakdown };
}

/**
 * Generate a human-readable explanation for the decision.
 */
function explain(score, decision, findings) {
  const critical = findings.filter(f => f.severity === 'critical');
  const high     = findings.filter(f => f.severity === 'high');
  const medium   = findings.filter(f => f.severity === 'medium');

  if (decision === 'BLOCK') {
    return {
      headline: '🚫 BLOCK — Critical Issues Found',
      summary:  `Risk score ${score}/100. ${critical.length} critical finding(s) must be resolved before publish.`,
      action:   'Fix the critical issues listed below and resubmit for a free rescan.',
      fixes:    critical.concat(high).map(f => ({ title: f.title, fix: f.fix })),
    };
  }

  if (decision === 'REVIEW') {
    return {
      headline: '⚠️ REVIEW — Human Check Required',
      summary:  `Risk score ${score}/100. ${high.length} high and ${medium.length} medium finding(s) queued for Trust Ops review.`,
      action:   'Our Trust Ops team will review your submission within 24–48 hours.',
      fixes:    high.concat(medium).map(f => ({ title: f.title, fix: f.fix })),
    };
  }

  return {
    headline: '✅ ALLOW — Ready to Publish',
    summary:  `Risk score ${score}/100. All checks passed. Your app is cleared for publish.`,
    action:   'Click "Publish Now" to make your app live in the store.',
    fixes:    [],
  };
}

module.exports = { calculate, explain, THRESHOLDS, POINTS };
